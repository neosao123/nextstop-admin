<?php

namespace App\Models\Superuser;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    protected function getDefaultGuardName(): string
    {
        return 'superuser';
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'contact_number',
        'avatar',
        'role',
        'reset_token',
		'add_id', 
		'add_ip',
		'edit_id',
		'edit_ip', 
		'delete_id',
		'delete_ip',
		'is_active',
		'is_delete'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];
	
	public static function filterUser(string $search = "", $limit = 0, $offset = 0)
    {
		$query = self::select("users.*", 'roles.name as role_name')
            ->join('roles', 'roles.id', '=', 'users.role')
			->where('users.is_delete', 0)
			->where('users.role', "!=",1)
            ->where(function ($query) use ($search) {
                $query->where('users.name', 'like', "%{$search}%")
                    ->orWhere('users.email', 'like', "%{$search}%")
                    ->orWhere('users.contact_number', 'like', "%{$search}%")
					->orWhere('roles.name', 'like', "%{$search}%");
            })
            ->orderBy('users.id', 'DESC');

        $total = $query->count();
        if ($limit && $limit > 0) {
            $query->limit($limit)->offset($offset);
        }
        $result = $query->get();
        return ["totalRecords" => $total, "result" => $result];
	}		
}
