<?php

namespace App\Models\Superuser;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    use HasFactory;
	protected $table="subscriptions";
    protected $fillable = [
        'plan_mode',
        'payment_gateway',
        'txn_id',
        'txn_date',
        'txn_status',
        'expiry_date',
        'tnx_request',
        'txn_response',
        'plan_config',
        'plan_status',
        'order_id',
		'tenant_id',
		'no_of_users',
		'no_of_project',
		'plan_name'
    ];

    public static function filtersSubscription(string $search = "", string $txn_id = "", string $txn_status = "", string $company_name="", int $limit = 0, int $offset = 0)
    {
        $query = self::select("subscriptions.*","tenants.company_name")
		    ->join("tenants","tenants.id","=","subscriptions.tenant_id")
			->where('subscriptions.plan_status','=','active')
            ->where(function ($query) use ($search) {
                $query->where('subscriptions.txn_id', 'like', "%{$search}%")
                     ->orWhere('subscriptions.txn_status', 'like', "%{$search}%")
					 ->orWhere('subscriptions.plan_mode', 'like', "%{$search}%")
					 ->orWhere('subscriptions.plan_name', 'like', "%{$search}%")
					 ->orWhere('subscriptions.txn_id', 'like', "%{$search}%")
					 ->orWhere('subscriptions.no_of_users', 'like', "%{$search}%")
					 ->orWhere('subscriptions.no_of_project', 'like', "%{$search}%")
					 ->orWhere('tenants.company_name', 'like', "%{$search}%");
            })
			
            ->orderBy('subscriptions.id', 'DESC');

        if ($txn_id != "") {
            $query->where('subscriptions.txn_id', $txn_id);
        }
        if ($txn_status != "") {
            $query->where('subscriptions.txn_status', $txn_status);
        }
		if ($company_name != "") {
            $query->where('tenants.company_name', $company_name);
        }

        $total = $query->count();
        if ($limit && $limit > 0) {
            $query->limit($limit)->offset($offset);
        }
        $result = $query->get();

        return ["totalRecords" => $total, "result" => $result];
    }
}
